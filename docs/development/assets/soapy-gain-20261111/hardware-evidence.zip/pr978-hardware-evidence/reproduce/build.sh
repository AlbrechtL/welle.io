#!/bin/sh
# Rebuild-only recipe; does not open SDR hardware.
set -eu
cxx=${CXX:-g++}
for variant in fixed old; do
    source=src/input/soapy_sdr.cpp
    if [ "$variant" = old ]; then source=soapy_sdr-old.cpp; fi
    "$cxx" -std=c++14 -O2 -pthread -DHAVE_SOAPYSDR \
      -Isrc -Isrc/input -Isrc/backend -Isrc/various -Isrc/tests/common \
      hardware-gain.cpp "$source" -lSoapySDR -o "hw-$variant"
done
