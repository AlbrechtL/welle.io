/* Physical-device check of the production CSoapySdr gain decrease method.
 * Generated with the help of an AI assistant (OpenAI Codex).
 * GPL version 2 or later; distributed WITHOUT ANY WARRANTY.
 * See the accompanying COPYING for full license terms.
 */
#include <chrono>
#include <cmath>
#include <iostream>
#include <stdexcept>
#include <thread>
#include <vector>
#include "input/soapy_sdr.h"
#include "null_radio_controller.h"

class TestSoapyGain {
    struct Samples { unsigned long long count=0; double power=0; };
    static Samples read(CSoapySdr& input, int milliseconds) {
        Samples result; std::vector<DSPCOMPLEX> buffer(32768);
        const auto until=std::chrono::steady_clock::now()+std::chrono::milliseconds(milliseconds);
        while (std::chrono::steady_clock::now()<until) {
            const int n=input.getSamples(buffer.data(), buffer.size());
            for(int i=0;i<n;i++) {
                const double v=std::norm(buffer[i]);
                if(!std::isfinite(v)) throw std::runtime_error("non-finite hardware IQ");
                result.power+=v;
            }
            result.count+=n;
            if(!n) std::this_thread::sleep_for(std::chrono::milliseconds(1));
        }
        if(result.count) result.power/=result.count;
        return result;
    }
public:
    static int run() {
        NullRadioController controller;
        CSoapySdr input(controller);
        // Exact device restriction before restart: never default-select the 7B SDR.
        input.m_driver_args="driver=soapyMiri,serial=1:1.2,transfer=BULK";
        input.setFrequency(190640000); // HR 7B on the temporarily borrowed 6A device.
        input.setAgc(false); // Directly exercise the unchanged AGC decrease function.
        if(!input.restart()) throw std::runtime_error("hardware restart failed");
        if(input.m_gains.size()<3) throw std::runtime_error("insufficient hardware gain steps");
        const auto range=input.m_device->getGainRange(SOAPY_SDR_RX,0);
        std::cout << "{\"kind\":\"device\",\"driver\":\"" << input.m_device->getDriverKey()
                  << "\",\"range_min\":" << range.minimum() << ",\"range_max\":" << range.maximum()
                  << ",\"table_min\":" << input.m_gains.front() << ",\"table_max\":" << input.m_gains.back()
                  << ",\"sample_rate\":" << input.m_device->getSampleRate(SOAPY_SDR_RX,0) << "}" << std::endl;
        read(input,500);
        const std::vector<double> starts={input.m_gains.front(),input.m_gains[input.m_gains.size()/2],79.0,input.m_gains.back(),range.maximum()};
        int failed=0;
        for(const double requested:starts) {
            if(requested<range.minimum() || requested>range.maximum()) throw std::runtime_error("test gain out of actual range");
            input.m_device->setGain(SOAPY_SDR_RX,0,requested);
            read(input,250); // Drain pre-change IQ and allow hardware settling.
            const double before=input.getGain();
            const auto beforeSamples=read(input,250);
            double expected=before;
            // Independent forward oracle: greatest table entry strictly below actual gain.
            for(double g:input.m_gains) if(g<before) expected=g;
            input.decreaseGain(); // Actual production method compiled from PR #978.
            read(input,250);
            const double after=input.getGain();
            const auto afterSamples=read(input,250);
            const bool ok=std::abs(after-expected)<0.01 && beforeSamples.count>10000 && afterSamples.count>10000
                          && beforeSamples.power>0 && afterSamples.power>0;
            if(!ok) failed++;
            std::cout << "{\"kind\":\"case\",\"requested\":" << requested << ",\"before\":" << before
                      << ",\"expected\":" << expected << ",\"after\":" << after
                      << ",\"before_samples\":" << beforeSamples.count << ",\"after_samples\":" << afterSamples.count
                      << ",\"before_power\":" << beforeSamples.power << ",\"after_power\":" << afterSamples.power
                      << ",\"passed\":" << (ok?"true":"false") << "}" << std::endl;
        }
        input.stop();
        std::cout << "{\"kind\":\"summary\",\"cases\":5,\"failed\":" << failed << "}" << std::endl;
        return failed?2:0;
    }
};
int main(int argc,char** argv) {
    if(argc!=2 || std::string(argv[1])!="--run-test-hardware") {
        std::cerr << "Explicit --run-test-hardware required; 6A service must be stopped first.\n";
        return 64;
    }
    try { return TestSoapyGain::run(); }
    catch(const std::exception& e) { std::cerr << e.what() << '\n';return 3; }
    catch(...) { std::cerr << "Unknown device failure\n";return 3; }
}
