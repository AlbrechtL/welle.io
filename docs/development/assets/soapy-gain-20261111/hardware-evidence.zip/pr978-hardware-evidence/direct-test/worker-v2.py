#!/usr/bin/python3
"""Bounded PR978 physical-device check; restores the borrowed 6A service."""
import json, os, pathlib, subprocess, sys, time, urllib.request, traceback
ROOT=pathlib.Path(__file__).resolve().parent
UNIT='welle-hessen6a.service'
KEEP='welle-cli.service'

def cmd(*args,timeout=20):
    return subprocess.check_output(args,text=True,timeout=timeout).strip()
def prop(unit,key):return cmd('systemctl','show',unit,'-p',key,'--value')
def snapshot(port):
    try:
        with urllib.request.urlopen(f'http://127.0.0.1:{port}/mux.json',timeout=3) as r:return json.load(r)
    except Exception as e:return {'error':str(e)}
def save(name,data):
    (ROOT/name).write_text(json.dumps(data,indent=2)+'\n')
def keep_ok(pid):
    if prop(KEEP,'MainPID')!=pid or prop(KEEP,'ActiveState')!='active':raise RuntimeError('7B production PID/state changed')
def main():
    assert os.geteuid()==0
    pid=prop(KEEP,'MainPID');assert int(pid)>1
    assert prop(UNIT,'ActiveState')=='active'
    testpid=prop(UNIT,'MainPID');assert int(testpid)>1
    keepcmd=pathlib.Path('/proc',pid,'cmdline').read_bytes()
    testcmd=pathlib.Path('/proc',testpid,'cmdline').read_bytes()
    assert b'serial=1:1.4' in keepcmd and b'\x007B\x00' in keepcmd,'Unexpected protected receiver'
    assert b'serial=1:1.2' in testcmd and b'\x006A\x00' in testcmd,'Unexpected borrowed receiver'
    before7=snapshot(7979)
    assert before7.get('demodulator',{}).get('synced') is True,'7B not synchronized before test'
    before={'at':time.time(),'7b_pid':pid,'6a_pid':testpid,'7b':before7,'6a':snapshot(7980)}
    save('before.json',before)
    report={'started':time.time(),'revision':'880df75742b3e878645c901c9f5e2994b9a829fb','hardware_serial':'1:1.2','test_channel':'7B','runs':[]}
    restore=False
    try:
        restore=True
        stopping=subprocess.Popen(['systemctl','stop',UNIT])
        deadline=time.monotonic()+25
        while stopping.poll() is None and time.monotonic()<deadline:
            # Release the pre-existing blocking HTTP accept after the stop signal.
            try:
                with urllib.request.urlopen('http://127.0.0.1:7980/mux.json',timeout=0.3) as response: response.read(1)
            except Exception: pass
            time.sleep(0.2)
        assert stopping.wait(timeout=2)==0, 'Stop command failed'
        state=prop(UNIT,'ActiveState'); mainpid=prop(UNIT,'MainPID')
        group=prop(UNIT,'ControlGroup')
        procs=pathlib.Path('/sys/fs/cgroup'+group+'/cgroup.procs') if group else None
        remaining=procs.read_text().strip() if procs and procs.exists() else ''
        report['stopped_state']={'state':state,'pid':mainpid,'remaining':remaining,'result':prop(UNIT,'Result')}
        assert state in ('inactive','failed') and mainpid=='0' and not remaining, 'Receiver has not fully stopped'
        keep_ok(pid)
        for number,variant in enumerate(('fixed','fixed','fixed','old')):
            keep_ok(pid)
            binary=ROOT/('hw-'+variant)
            args=['runuser','-u','pi','--','env','LD_LIBRARY_PATH=/opt/welle-miri-20261002-gainfix/lib',
                  'SOAPY_SDR_PLUGIN_PATH=/opt/welle-miri-20261002-gainfix/lib/SoapySDR/modules0.8',
                  'timeout','--signal=TERM','--kill-after=5','25',str(binary),'--run-test-hardware']
            print('TEST',number+1,variant,flush=True)
            result=subprocess.run(args,capture_output=True,text=True,timeout=35)
            (ROOT/f'{number}-{variant}.stdout').write_text(result.stdout)
            (ROOT/f'{number}-{variant}.stderr').write_text(result.stderr)
            rows=[json.loads(line) for line in result.stdout.splitlines() if line.startswith('{')]
            cases=[x for x in rows if x.get('kind')=='case']
            summaries=[x for x in rows if x.get('kind')=='summary']
            iq= len(cases)==5 and all(x['before_samples']>10000 and x['after_samples']>10000 and x['before_power']>0 and x['after_power']>0 for x in cases)
            gainfails=sum(abs(x['after']-x['expected'])>=0.01 for x in cases)
            passed=iq and len(summaries)==1 and ((variant=='fixed' and result.returncode==0 and summaries[0]['failed']==0) or (variant=='old' and result.returncode==2 and gainfails>=2))
            row={'variant':variant,'exit':result.returncode,'passed':passed,'cases':cases,'gain_failures':gainfails}
            report['runs'].append(row);save('report.json',report)
            print(json.dumps(row),flush=True)
            keep_ok(pid)
            if not passed:raise RuntimeError('Hardware check did not meet expected outcome')
    except BaseException as e:
        report['test_error']=repr(e);report['traceback']=traceback.format_exc()
    finally:
        if restore:
            print('RESTORE original 6A service',flush=True)
            try:subprocess.run(['systemctl','start',UNIT],check=True,timeout=25)
            except Exception as e:report['restore_error']=repr(e)
        report['6a_active']=prop(UNIT,'ActiveState')
        report['6a_pid_after']=prop(UNIT,'MainPID')
        report['7b_pid_unchanged']=prop(KEEP,'MainPID')==pid
        report['after7b']=snapshot(7979)
        report['after6a']=snapshot(7980)
        report['hardware_test_passed']=len(report['runs'])==4 and all(x['passed'] for x in report['runs']) and 'test_error' not in report
        report['finished']=time.time()
        save('report.json',report)
    print('REPORT:',ROOT/'report.json',flush=True)
    print(json.dumps({k:report[k] for k in ('hardware_test_passed','6a_active','6a_pid_after','7b_pid_unchanged')}),flush=True)
    print('Fresh 6A/7B reception and decoded audio need a separate follow-up check.',flush=True)
    return 0 if report['hardware_test_passed'] and report['6a_active']=='active' and report['7b_pid_unchanged'] else 1
if __name__=='__main__':sys.exit(main())
