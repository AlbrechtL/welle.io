welle.io PR #978: physical SoapySDR gain-decrease test
===================================================
Date: 2026-11-11, 22:19:35–22:20:09 Europe/Berlin (UTC+01:00).
Revision: 880df75742b3e878645c901c9f5e2994b9a829fb

Scope and result
----------------
Actual Miri hardware, SoapySDR 0.8.1 (ABI 0.8), custom SoapyMiri driver,
libmirisdr-5, ARM64 Debian 13, kernel 6.18.50+rpt-rpi-v8.
The borrowed device was selected explicitly with
  driver=soapyMiri,serial=1:1.2,transfer=BULK
and tuned to 190640000 Hz (7B). The separate production 7B receiver
(serial=1:1.4) remained running with unchanged PID.

Three fixed runs, five cases each: 15/15 passed.
One negative-control run with ONLY '<' reverted to '>': 5/5 cases failed
the expected decrease, as intended. The control is not an unmodified
historical checkout: it is the SAME PR head with exactly that mutation.

Starting gain   expected / fixed result   old-comparison result
0               0                         101
51              50                        101
79              78                        101
101             100                       101
102             101                       102

How this was measured
---------------------
The harness compiles the actual CSoapySdr production implementation.
The existing TestSoapyGain friend gives access to decreaseGain().
It opens the physical device and runs the production IQ worker.
For each case, it sets the initial gain via SoapySDR, drains 250 ms,
reads getGain(), measures another 250 ms of IQ, invokes decreaseGain(),
drains 250 ms, reads getGain() again, and measures another 250 ms of IQ.
The oracle independently scans forwards for the greatest table value
strictly below the reported initial gain. At the lower boundary it
expects no change. All windows contained >10000 finite, nonzero IQ samples.

Gain values are the driver's getGain() report (libmirisdr derives this
from stored gain-stage settings), NOT independent calibrated
RF gain measurements or a claim that physical hardware registers were read.
IQ power is mean |I+jQ|^2 in driver units, NOT calibrated dBm. The direct
harness disables automatic AGC to isolate the decrease method; this is
not a full automatic-AGC reception or decoder test. This attachment covers
only the direct hardware gain-decrease test on 7B.

PR scope
--------
The driver advertises 0..102; the existing table contains 0..101.
This test records that existing boundary behavior without changing it.
No claim is made about other drivers, non-integer gain steps, or long runs.

Files and reproducibility
-------------------------
direct-test/*.stdout and *.stderr: original unmodified program output.
gain-results.csv: all 20 cases in a spreadsheet-friendly table.
result.json: run results and timestamps (Unix seconds).
manifest.json: original source/binary checksums. worker.py is the FIRST
launcher payload (aborted before testing). worker-v2.py is the corrected
worker used for the successful run. Both are included for transparency;
see SHA256SUMS for all actual files. The original manifest is unchanged.
old-comparison.patch: exact counter-test mutation.
reproduce/: the source/header subset and GPL COPYING used by the harness.
reproduce/build.sh: standalone rebuild recipe requiring g++ and SoapySDR
headers/library. Rebuild hashes can differ with compiler/toolchain options.

Execution, only after releasing the selected device from its normal owner:
  LD_LIBRARY_PATH=/opt/welle-miri-20261002-gainfix/lib \
  SOAPY_SDR_PLUGIN_PATH=/opt/welle-miri-20261002-gainfix/lib/SoapySDR/modules0.8 \
  timeout --signal=TERM --kill-after=5 25 ./hw-fixed --run-test-hardware
The old control exits 2 because the decrease checks intentionally fail.
Change the explicit device selection in the harness for a different host;
never run against a device already owned by another receiver.
The workers included for audit are host-specific, not generic installers.
Use worker-v2.py when inspecting the successful test; worker.py documents
the initial aborted attempt only.

An initial orchestration attempt aborted BEFORE any hardware case because
the normal receiver's stop timed out and systemd reported 'failed' despite
MainPID=0. It was restored. The corrected worker verifies PID and empty
cgroup, accepts a fully stopped failed unit, and has automatic restoration.
Only the subsequent completed run is counted in the 15/15 result.

Verification
------------
SHA256SUMS covers all attached files. Hashes establish integrity against
this manifest; they are not independent third-party certification.
No activation keys, credentials or broadcast audio are included.
